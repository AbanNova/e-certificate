<?php return array (
  'certificates' => 'App\\Http\\Livewire\\Certificates',
  'courses' => 'App\\Http\\Livewire\\Courses',
  'new-certificate' => 'App\\Http\\Livewire\\NewCertificate',
  'new-course' => 'App\\Http\\Livewire\\NewCourse',
  'validate-certificate' => 'App\\Http\\Livewire\\ValidateCertificate',
  'validate-certificate-q-r' => 'App\\Http\\Livewire\\ValidateCertificateQR',
);